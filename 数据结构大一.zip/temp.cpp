#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include<sstream>
#include <stack>
#include<map>
using namespace std;
